import { readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
const root = process.argv[2] ? resolve(process.argv[2]) : import.meta.dirname;
const outcomes = JSON.parse(readFileSync(join(root, 'first-pass-outcomes.json'), 'utf8'));
const conflicts = [];
const pattern = /^<<<<<<< [^\n]*\n([\s\S]*?)^\|\|\|\|\|\|\| [^\n]*\n([\s\S]*?)^=======\r?\n([\s\S]*?)^>>>>>>> [^\n]*\n?/gm;
for (const outcome of outcomes.filter(item => item.result === 'conflict')) {
  const source = readFileSync(join(root, 'auto-merged', outcome.path), 'utf8');
  let index = 0;
  for (const match of source.matchAll(pattern)) {
    conflicts.push({ path: outcome.path, hunk: ++index,
      upstream: match[1].trimEnd(), base: match[2].trimEnd(), localized: match[3].trimEnd() });
  }
  if (index !== outcome.conflictCount) throw new Error(`${outcome.path}: expected ${outcome.conflictCount}, parsed ${index}`);
}
writeFileSync(join(root, 'conflict-hunks.json'), `${JSON.stringify(conflicts, null, 2)}\n`);
console.log(`Extracted ${conflicts.length} conflict hunks from ${outcomes.filter(x => x.result === 'conflict').length} files`);
for (const item of conflicts) {
  const short = text => text.replace(/\s+/g, ' ').slice(0, 190);
  console.log(`${item.path} #${item.hunk}\n  upstream: ${short(item.upstream)}\n  localized: ${short(item.localized)}`);
}

