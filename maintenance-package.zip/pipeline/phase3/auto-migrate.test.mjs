import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const script = join(dirname(fileURLToPath(import.meta.url)), 'auto-migrate.mjs');

function fixture(fn) {
  const root = mkdtempSync(join(tmpdir(), 'cline-chinese-migrate-test-'));
  const base = join(root, 'base');
  const localized = join(root, 'localized');
  const upstream = join(root, 'upstream');
  const run = join(root, 'run');
  for (const path of [base, localized, upstream]) mkdirSync(path);
  const put = (tree, path, contents) => {
    const target = join(tree, path);
    mkdirSync(dirname(target), { recursive: true });
    writeFileSync(target, contents);
  };
  try {
    fn({ base, localized, upstream, run, put });
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
}

test('hashes regular files and classifies an upstream directory as an added collision', () => {
  fixture(({ base, localized, upstream, run, put }) => {
    put(base, 'changed.txt', 'base');
    put(localized, 'changed.txt', 'Chinese');
    put(upstream, 'changed.txt', 'base');
    put(localized, 'collision', 'local file');
    put(upstream, 'collision/child.txt', 'upstream directory child');
    const result = spawnSync(process.execPath, [script, base, localized, upstream, run], { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
    const outcomes = JSON.parse(readFileSync(join(run, 'first-pass-outcomes.json'), 'utf8'));
    assert.deepEqual(outcomes.find(item => item.path === 'changed.txt'), { path: 'changed.txt', result: 'applied-clean' });
    assert.deepEqual(outcomes.find(item => item.path === 'collision'),
      { path: 'collision', result: 'added-collision', upstreamType: 'non-file' });
    assert.equal(readFileSync(join(run, 'auto-merged', 'changed.txt'), 'utf8'), 'Chinese');
    assert.equal(readFileSync(join(run, 'auto-merged', 'collision', 'child.txt'), 'utf8'), 'upstream directory child');
  });
});

test('reports a modified file replaced upstream by a directory as a structural conflict', () => {
  fixture(({ base, localized, upstream, run, put }) => {
    put(base, 'replaced', 'base');
    put(localized, 'replaced', 'Chinese');
    put(upstream, 'replaced/child.txt', 'upstream directory child');
    const result = spawnSync(process.execPath, [script, base, localized, upstream, run], { encoding: 'utf8' });
    assert.equal(result.status, 2, result.stderr);
    const outcomes = JSON.parse(readFileSync(join(run, 'first-pass-outcomes.json'), 'utf8'));
    assert.deepEqual(outcomes, [{ path: 'replaced', result: 'path-type-conflict', upstreamType: 'non-file' }]);
  });
});
