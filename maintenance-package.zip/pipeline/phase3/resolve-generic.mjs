// Reusable conflict policy: keep new upstream control flow, then reapply
// localization mechanically. Any remaining semantic mismatch is a test failure
// or a documented manual review item, never silently accepted.
import { cpSync, readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { reapplyUpdaterLocalization } from './reapply-updater-localization.mjs';
import { reapplyRunErrorLocalization } from './reapply-run-error-localization.mjs';

const [runRootArg, localizedArg, outputArg] = process.argv.slice(2);
if (![runRootArg, localizedArg, outputArg].every(Boolean))
  throw new Error('Usage: node resolve-generic.mjs RUN_ROOT LOCALIZED OUTPUT');
const runRoot = resolve(runRootArg);
const input = join(runRoot, 'auto-merged');
const output = resolve(outputArg);
const conflicts = JSON.parse(readFileSync(join(runRoot, 'first-pass-outcomes.json'), 'utf8'))
  .filter(item => item.result === 'conflict');
const reviewed = conflicts.length
  ? JSON.parse(readFileSync(join(runRoot, 'conflict-classification.json'), 'utf8'))
  : [];
const expectedHunks = conflicts.reduce((sum, item) => sum + item.conflictCount, 0);
if (reviewed.length !== expectedHunks || reviewed.some(item =>
  !conflicts.some(conflict => conflict.path === item.path && item.hunk >= 1 && item.hunk <= conflict.conflictCount) ||
  !['mechanical', 'semantic', 'obsolete'].includes(item.category) ||
  !['upstream+rule', 'upstream-native'].includes(item.resolution)))
  throw new Error('Conflicts require a complete reviewed classification before resolution');
cpSync(input, output, { recursive: true, force: false, errorOnExist: true });
const marker = /^<<<<<<< [^\n]*\n([\s\S]*?)^\|\|\|\|\|\|\| [^\n]*\n[\s\S]*?^=======\r?\n[\s\S]*?^>>>>>>> [^\n]*\n?/gm;
let resolvedHunks = 0;
for (const conflict of conflicts) {
  const path = join(output, conflict.path);
  let source = readFileSync(path, 'utf8');
  let count = 0;
  source = source.replace(marker, (_whole, upstream) => {
    count++;
    return upstream;
  });
  if (count !== conflict.conflictCount || source.includes('<<<<<<< '))
    throw new Error(`${conflict.path}: resolved ${count}/${conflict.conflictCount}`);
  writeFileSync(path, source);
  resolvedHunks += count;
}

const app = join(output, 'apps', 'examples', 'desktop-app');
const localApp = join(resolve(localizedArg), 'apps', 'examples', 'desktop-app');
const packagePath = join(app, 'package.json');
const manifest = JSON.parse(readFileSync(packagePath, 'utf8'));
const localManifest = JSON.parse(readFileSync(join(localApp, 'package.json'), 'utf8'));
for (const [name, command] of Object.entries(localManifest.scripts)) {
  if (name.startsWith('i18n:') && !manifest.scripts[name]) manifest.scripts[name] = command;
}
for (const section of ['dependencies', 'devDependencies']) {
  manifest[section] ??= {};
  for (const [name, version] of Object.entries(localManifest[section] ?? {})) {
    if (!/^(?:i18next|react-i18next)$/.test(name)) continue;
    if (manifest[section][name] && manifest[section][name] !== version)
      throw new Error(`Dependency ${name} changed upstream; review required`);
    manifest[section][name] = version;
  }
}
writeFileSync(packagePath, `${JSON.stringify(manifest, null, 2)}\n`);

// A merged file can retain t(...) call sites while an import was on the other
// side of an upstream conflict. Repair the import only in those files.
for (const conflict of conflicts) {
  if (!/^apps\/examples\/desktop-app\/webview\/.*\.tsx?$/.test(conflict.path)) continue;
  const path = join(output, conflict.path);
  let source = readFileSync(path, 'utf8');
  if (!/\bt\(\s*["']/.test(source) || /import\s*\{[^}]*\bt\b[^}]*\}\s*from\s*["']@\/i18n["']/.test(source)) continue;
  const directive = source.match(/^"use client";?\s*\n/);
  const offset = directive ? directive[0].length : 0;
  source = `${source.slice(0, offset)}import { t } from "@/i18n";\n${source.slice(offset)}`;
  writeFileSync(path, source);
}
reapplyUpdaterLocalization(output);
reapplyRunErrorLocalization(output);
console.log(`Resolved ${resolvedHunks} hunks in ${conflicts.length} files with upstream behavior; restored i18n scripts/imports and updater strings`);


