// Parameterized Phase 2 inventory + git merge-file migration. This first pass
// intentionally contains no rules specific to the 0.0.33 source contents.
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';

const [baseArg, localizedArg, upstreamArg, runRootArg] = process.argv.slice(2);
if (![baseArg, localizedArg, upstreamArg, runRootArg].every(Boolean))
  throw new Error('Usage: node auto-migrate.mjs BASE LOCALIZED UPSTREAM RUN_ROOT');
const base = resolve(baseArg);
const localized = resolve(localizedArg);
const upstream = resolve(upstreamArg);
const runRoot = resolve(runRootArg);
const merged = join(runRoot, 'auto-merged');
const skipDirs = new Set(['.git', 'node_modules', '.next', 'out', 'target', 'dist', '.turbo', 'gen']);
const skipFiles = [/\.tsbuildinfo$/, /\.exe$/, /\.pdb$/, /\.log$/, /\.o$/,
  /^apps\/examples\/desktop-app\/src-tauri\/tauri\.(?:phase\d+-test|isolated-test)\.conf\.json$/];

function files(directory) {
  const found = new Set();
  function visit(folder) {
    for (const entry of readdirSync(folder, { withFileTypes: true })) {
      if (entry.isDirectory() && skipDirs.has(entry.name)) continue;
      const path = join(folder, entry.name);
      if (entry.isDirectory()) visit(path);
      else if (entry.isFile()) {
        const rel = relative(directory, path).replaceAll('\\', '/');
        if (!skipFiles.some(pattern => pattern.test(rel))) found.add(rel);
      }
    }
  }
  visit(directory);
  return found;
}
const isRegularFile = path => existsSync(path) && statSync(path).isFile();
const hash = path => {
  if (!isRegularFile(path)) throw new TypeError(`Cannot hash a non-file path: ${path}`);
  return createHash('sha256').update(readFileSync(path)).digest('hex');
};
if (existsSync(merged)) throw new Error('auto-merged already exists; first-pass result is immutable');
for (const path of [base, localized, upstream]) if (!existsSync(path)) throw new Error(`missing ${path}`);
mkdirSync(runRoot, { recursive: true });

const baseFiles = files(base);
const localFiles = files(localized);
const changes = [];
for (const path of localFiles) {
  if (!baseFiles.has(path)) changes.push({ path, kind: 'added' });
  else if (hash(join(localized, path)) !== hash(join(base, path))) changes.push({ path, kind: 'modified' });
}
for (const path of baseFiles) if (!localFiles.has(path)) changes.push({ path, kind: 'deleted' });
changes.sort((a, b) => a.path.localeCompare(b.path));
writeFileSync(join(runRoot, 'patch-inventory.json'), `${JSON.stringify(changes, null, 2)}\n`);

cpSync(upstream, merged, { recursive: true, force: false, errorOnExist: true, filter: src => {
  const parts = relative(upstream, src).split(/[\\/]/).filter(Boolean);
  return !parts.some(part => skipDirs.has(part));
} });
const outcomes = [];
for (const change of changes) {
  const path = change.path;
  if (path === 'bun.lock') { outcomes.push({ path, result: 'regenerate-lockfile' }); continue; }
  const basePath = join(base, path), localPath = join(localized, path);
  const upstreamPath = join(upstream, path), destination = join(merged, path);
  if (change.kind === 'added') {
    if (!existsSync(upstreamPath)) {
      mkdirSync(dirname(destination), { recursive: true });
      cpSync(localPath, destination);
      outcomes.push({ path, result: 'added' });
    } else if (!isRegularFile(upstreamPath)) outcomes.push({ path, result: 'added-collision', upstreamType: 'non-file' });
    else if (hash(localPath) === hash(upstreamPath)) outcomes.push({ path, result: 'already-upstream' });
    else outcomes.push({ path, result: 'added-collision' });
    continue;
  }
  if (change.kind === 'deleted') {
    outcomes.push({ path, result: existsSync(upstreamPath) ? 'deleted-upstream-exists' : 'already-deleted-upstream' });
    continue;
  }
  if (!existsSync(upstreamPath)) { outcomes.push({ path, result: 'removed-upstream' }); continue; }
  if (!isRegularFile(upstreamPath)) { outcomes.push({ path, result: 'path-type-conflict', upstreamType: 'non-file' }); continue; }
  if (hash(upstreamPath) === hash(basePath)) {
    cpSync(localPath, destination, { force: true });
    outcomes.push({ path, result: 'applied-clean' });
    continue;
  }
  const result = spawnSync('git', ['merge-file', '--diff3', '-p', upstreamPath, basePath, localPath],
    { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  if (result.error || result.status === null || result.status < 0 || result.status > 125) {
    outcomes.push({ path, result: 'merge-error', error: result.stderr?.slice(0, 500) });
    continue;
  }
  writeFileSync(destination, result.stdout, 'utf8');
  outcomes.push({ path, result: result.status === 0 ? 'merged-clean' : 'conflict', conflictCount: result.status });
}
writeFileSync(join(runRoot, 'first-pass-outcomes.json'), `${JSON.stringify(outcomes, null, 2)}\n`);
const groups = Object.groupBy(outcomes, item => item.result);
console.log(JSON.stringify(Object.fromEntries(Object.entries(groups).map(([key, items]) => [key, items.length]))));
console.log(`Patch files: ${changes.length}`);
for (const outcome of outcomes.filter(item => /conflict|error|collision|removed-upstream|deleted-upstream-exists/.test(item.result))) {
  console.log(`${outcome.result}: ${outcome.path}`);
}
if (outcomes.some(item => item.result === 'path-type-conflict')) process.exitCode = 2;


