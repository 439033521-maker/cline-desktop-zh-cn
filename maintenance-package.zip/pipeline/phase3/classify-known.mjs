import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const [runArg, rulesArg] = process.argv.slice(2);
if (!runArg || !rulesArg) throw new Error('Usage: node classify-known.mjs RUN_ROOT KNOWN_CONFLICTS_JSON');
const run = resolve(runArg);
const hunks = JSON.parse(readFileSync(join(run, 'conflict-hunks.json'), 'utf8'));
const rules = JSON.parse(readFileSync(resolve(rulesArg), 'utf8'));
const recognized = [];
const unknown = [];
for (const hunk of hunks) {
  const sha256 = createHash('sha256').update(JSON.stringify({
    upstream: hunk.upstream, base: hunk.base, localized: hunk.localized,
  })).digest('hex');
  const rule = rules.find(item => item.path === hunk.path && item.hunk === hunk.hunk && item.sha256 === sha256);
  if (rule) recognized.push({path: rule.path, hunk: rule.hunk, category: rule.category,
    detail: rule.detail, resolution: rule.resolution});
  else unknown.push({path: hunk.path, hunk: hunk.hunk, sha256});
}
writeFileSync(join(run, 'unknown-conflicts.json'), JSON.stringify(unknown, null, 2) + '\n');
if (unknown.length) {
  console.error(`${unknown.length} unrecognized conflict hunk(s); fail fast`);
  process.exit(2);
}
writeFileSync(join(run, 'conflict-classification.json'), JSON.stringify(recognized, null, 2) + '\n');
console.log(`Known conflict rules matched ${recognized.length}/${hunks.length} hunks`);
