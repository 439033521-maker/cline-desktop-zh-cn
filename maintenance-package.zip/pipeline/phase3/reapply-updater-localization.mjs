// Reapply updater UI text after a merge keeps upstream's newer updater control flow.
// Match message shapes, not release numbers. A changed upstream shape fails visibly
// so the next migration cannot silently ship English update actions.
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

function update(path, replacements) {
  let source = readFileSync(path, 'utf8');
  for (const [raw, localized] of replacements) {
    if (source.includes(raw)) source = source.replaceAll(raw, localized);
    else if (!source.includes(localized)) throw new Error(`Updater localization shape changed: ${path}: ${raw}`);
  }
  writeFileSync(path, source);
}

export function reapplyUpdaterLocalization(tree) {
  const webview = join(tree, 'apps', 'examples', 'desktop-app', 'webview');
  update(join(webview, 'hooks', 'use-app-update.tsx'), [
    ['`Update ready: v${version}`', 't("Update ready: v{{version}}", { version })'],
    ['altText="Restart now"', 'altText={t("Restart now")}'],
    ['\n\t\t\t\tRestart now\n', '\n\t\t\t\t{t("Restart now")}\n'],
  ]);
  update(join(webview, 'components', 'app-update-indicator.tsx'), [
    ['`Update ready: v${status.version}`', 't("Update ready: v{{version}}", { version: status.version })'],
    ['<p className="text-sm font-medium">Update ready: v{status.version}</p>', '<p className="text-sm font-medium">{t("Update ready: v{{version}}", { version: status.version })}</p>'],
    ['The new version has been downloaded and will be used the next time the\n\t\t\t\t\tapp starts. Restart now to switch to it right away.', '{t("The new version has been downloaded and will be used the next time the app starts. Restart now to switch to it right away.")}'],
    ['\n\t\t\t\t\t\t\tRestarting...\n', '\n\t\t\t\t\t\t\t{t("Restarting...")}\n'],
  ]);
  const catalogPath = join(webview, 'i18n', 'locales', 'zh-CN', 'common.json');
  const catalog = JSON.parse(readFileSync(catalogPath, 'utf8'));
  Object.assign(catalog, {
    'Update ready: v{{version}}': '更新已就绪：v{{version}}',
    'The new version has been downloaded and will be used the next time the app starts. Restart now to switch to it right away.': '新版本已下载完成，下次启动时会启用。立即重启即可切换到新版本。',
    'Restarting...': '正在重启...',
  });
  writeFileSync(catalogPath, `${JSON.stringify(catalog, null, '\t')}\n`);
}

if (process.argv[1] && import.meta.url === new URL(`file:///${process.argv[1].replaceAll('\\', '/')}`).href) {
  reapplyUpdaterLocalization(process.argv[2]);
}
