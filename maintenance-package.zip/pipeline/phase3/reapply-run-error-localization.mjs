// Reapply Chinese presentation at the shared Desktop error formatter introduced
// upstream in 0.0.34. Keep upstream error metadata and raw provider detail.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const appPath = 'apps/examples/desktop-app/webview';
const translations = {
  'The run failed': '运行失败',
  'The run failed: {{detail}}': '运行失败：{{detail}}',
  'The run failed before a response was produced.': '本次运行在产生任何响应之前就失败了。',
  'Sign in again with the {{command}} CLI in a terminal, then try again.': '请在终端使用 {{command}} CLI 重新登录，然后重试。',
  'Sign in to Cline again in Settings → Account, then try again.': '请在“设置 → 账户”中重新登录 Cline，然后重试。',
  'Check your model connection in Settings → API Providers (or sign in with Cline), then try again.': '请在“设置 → API 提供商”中检查模型连接（或重新登录 Cline），然后重试。',
};

function replaceRequired(source, before, after, label) {
  if (!source.includes(before)) throw new Error(`${label}: upstream structure changed; review required`);
  return source.replace(before, after);
}

export function reapplyRunErrorLocalization(sourceRoot) {
  const web = join(resolve(sourceRoot), appPath);
  const runErrorPath = join(web, 'lib', 'run-error.ts');
  if (!existsSync(runErrorPath)) throw new Error('run-error.ts moved or removed; review required');
  let runError = readFileSync(runErrorPath, 'utf8');
  if (!runError.includes('import { t } from "@/i18n";')) {
    runError = replaceRequired(runError,
      '} from "@/hooks/chat-session/helpers";',
      '} from "@/hooks/chat-session/helpers";\nimport { t } from "@/i18n";',
      'run-error import');
  }
  if (!runError.includes('const localizedDescription =')) {
    runError = replaceRequired(runError,
      '\treturn [\n\t\tdescription\n\t\t\t? description.startsWith("The run failed")\n\t\t\t\t? description\n\t\t\t\t: `The run failed: ${description}`\n\t\t\t: "The run failed before a response was produced.",',
      '\tconst englishPrefix = "The run failed";\n' +
      '\tconst localizedPrefix = t(englishPrefix);\n' +
      '\tconst localizedDescription = description\n' +
      '\t\t? description.startsWith(englishPrefix)\n' +
      '\t\t\t? localizedPrefix === englishPrefix\n' +
      '\t\t\t\t? description\n' +
      '\t\t\t\t: `${localizedPrefix}${description.slice(englishPrefix.length).replace(/^: /, "：")}`\n' +
      '\t\t\t: description.startsWith(localizedPrefix)\n' +
      '\t\t\t\t? description\n' +
      '\t\t\t\t: t("The run failed: {{detail}}", { detail: description })\n' +
      '\t\t: t("The run failed before a response was produced.");\n' +
      '\treturn [\n\t\tlocalizedDescription,',
      'run-error formatter');
  }
  writeFileSync(runErrorPath, runError);

  const helpersPath = join(web, 'hooks', 'chat-session', 'helpers.ts');
  let helpers = readFileSync(helpersPath, 'utf8');
  if (!helpers.includes('import { t } from "@/i18n";')) {
    helpers = replaceRequired(helpers,
      'import { normalizeProviderId } from "@/lib/provider-id";',
      'import { normalizeProviderId } from "@/lib/provider-id";\nimport { t } from "@/i18n";',
      'credential hint import');
  }
  if (!helpers.includes('t("Sign in again with the {{command}} CLI')) {
    helpers = replaceRequired(helpers,
      'return `Sign in again with the \\`${cli.command}\\` CLI in a terminal, then try again.`;',
      'return t("Sign in again with the {{command}} CLI in a terminal, then try again.", { command: `\\`${cli.command}\\`` });',
      'CLI credential hint');
    helpers = replaceRequired(helpers,
      'return "Sign in to Cline again in Settings → Account, then try again.";',
      'return t("Sign in to Cline again in Settings → Account, then try again.");',
      'Cline credential hint');
    helpers = replaceRequired(helpers,
      'return "Check your model connection in Settings → API Providers (or sign in with Cline), then try again.";',
      'return t("Check your model connection in Settings → API Providers (or sign in with Cline), then try again.");',
      'provider credential hint');
  }
  writeFileSync(helpersPath, helpers);

  const catalogPath = join(web, 'i18n', 'locales', 'zh-CN', 'common.json');
  const catalog = JSON.parse(readFileSync(catalogPath, 'utf8'));
  for (const [key, value] of Object.entries(translations)) {
    if (catalog[key] && catalog[key] !== value) throw new Error(`translation drift: ${key}`);
    catalog[key] = value;
  }
  writeFileSync(catalogPath, `${JSON.stringify(catalog, null, '\t')}\n`);

  const testPath = join(web, 'lib', 'run-error.zh.test.ts');
  if (!existsSync(testPath)) writeFileSync(testPath, `import { afterAll, beforeAll, describe, expect, it } from "vitest";
import i18n from "@/i18n";
import { formatRunError } from "./run-error";

describe("Chinese run error presentation", () => {
  let previousLanguage: string;
  beforeAll(async () => {
    previousLanguage = i18n.language;
    await i18n.changeLanguage("zh-CN");
  });
  afterAll(async () => { await i18n.changeLanguage(previousLanguage); });

  it("translates the wrapper while keeping provider detail literal and idempotent", () => {
    const text = formatRunError("The run failed: API key expired", "");
    expect(text).toContain("运行失败：API key expired");
    expect(text).toContain("API 提供商");
    expect(formatRunError(text)).toBe(text);
  });
  it("keeps CLI identifiers literal", () => {
    const text = formatRunError("session expired", "claude-code");
    expect(text).toContain("运行失败：session expired");
    expect(text).toContain("\`claude\` CLI");
    expect(text).not.toContain("API 提供商");
  });
  it("translates an empty response failure", () => {
    expect(formatRunError("")).toContain("本次运行在产生任何响应之前就失败了。");
  });
});
`);
  console.log('Chinese run-error presentation and regression test applied');
}

if (process.argv[1] && resolve(process.argv[1]) === import.meta.filename) {
  const root = process.argv[2];
  if (!root) throw new Error('Usage: node reapply-run-error-localization.mjs SOURCE_ROOT');
  reapplyRunErrorLocalization(root);
}
