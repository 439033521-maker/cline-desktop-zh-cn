# Cline Chinese fast maintenance

The production updater feed remains `https://github.com/439033521-maker/cline-desktop-zh-cn/releases/latest/download/latest.json`. The scheduled workflow compares that feed with the official stable Desktop feed every six hours. A newer stable release produces an **unsigned** Windows NSIS candidate and a report. GitHub Actions has no production updater private key, does not sign, and does not publish a stable Release.

The workflow reuses the official `desktop-v0.0.34` Windows toolchain/build order: Bun 1.3.13, Rust, UPX, SDK build, sidecar/remote-helper build, WebView build, Tauri NSIS. It adds the maintenance package migration and source checks before dependency installation. Known conflict hunks are recognized by content hash. An unknown hunk stops the job and uploads a small `agent-intervention` artifact containing the conflict slices and report. Bun and Rust caches are keyed by toolchain and upstream lockfiles; a Bun cache failure retries once without cache.

## 0.0.34 dry source rehearsal

- Official tag: `desktop-v0.0.34`; commit: `a094678c75ccabe63b0c2d3587e4c3a118f3a2f1`.
- 154 patch items: 55 added, 90 applied cleanly, 6 merged cleanly, 2 known conflicts, 1 lockfile regeneration. Automatic clean rate: 151/153 applicable source files, 98.7%.
- The manifest conflict is mechanical. The `use-chat-session.ts` conflict is semantic; the rule keeps upstream `formatRunError` and adds Chinese presentation at its new shared formatter.
- Source restoration, migration, known-conflict matching, static identity checks, and i18n key coverage passed without installing dependencies. Missing i18n keys: 0.
- Full cloud build, publish, and formal updater acceptance remain unverified until the workflow is committed and run.

## Local publishing

Run `SIGN-AND-PUBLISH.cmd` from this maintenance package, or use the desktop shortcut. `SIGN-AND-PUBLISH.cmd -SelfCheck` checks the local tools and GitHub login without downloading, signing, or publishing a candidate. The release machine needs Bun 1.3.13, authenticated `gh`, the vetted local minisign 0.12 binary, and the project-local `@tauri-apps/cli` **2.11.4** from `tools/tauri-cli/package.json` and `bun.lock`. If the local Tauri CLI is absent, the script restores this exact version with `bun install --frozen-lockfile`. It never runs Cargo or installs Rust, MSVC, or Visual Studio Build Tools. Tauri CLI is used only for `signer sign --private-key-path`; the public key is independently checked with minisign. The script downloads the newest successful candidate, checks version, official tag/commit, maintenance commit, gates, public key, and SHA-256; then asks for `PUBLISH` before signing. It passes only the local key **path** to the Tauri signer and suppresses signer output. A draft Release is remotely checked before being marked Latest.

The local signer route was verified on a harmless file using the production key path, `@tauri-apps/cli` 2.11.4, and minisign 0.12 with the production public key. The JS CLI's Windows package contains a precompiled native binary, so signing does not require a Rust compiler or `link.exe`. Bun is kept as a shared developer tool at `../SharedTools/Bun/1.3.13`; the maintenance package and publisher contain no path into the temporary 0.0.34 worktree. The official upstream 0.0.34 lockfile also resolves `@tauri-apps/cli` to 2.11.4.

New publishing dependencies must be chosen in this order: existing tools, official precompiled binary, project-local Bun/npm package, small independent CLI, and only then a locally compiled toolchain. Do not add a large compiler toolchain for a single signing or packaging command without a documented need. Agent fixes should become reusable rules plus a regression check where practical.

## Final NSIS payload integrity

Cloud builds now record the pre-bundle App/sidecar, the App path named by the generated NSIS script, the first Tauri NSIS payload, the patched NSIS source, the repacked payload, and the final promoted installer payload in `payload-trace.json`. The generated `nsis-output.exe` must be produced from the NSIS script directory and promoted to the actual candidate bundle path; otherwise the process-scope patch is not in the released installer. `collect-candidate.mjs` stops if any App or sidecar bytes change between these stages without a reviewed transformation rule. Metadata uses `payloadSchema: 1` and names `preBundleSha256` separately from `finalInstallerPayloadSha256`. The local publisher extracts the actual NSIS payload again and compares its App/sidecar hashes and bytes with cloud metadata before using the production signer. A draft remote installer is checked the same way before publication. Changes to this supply-chain check require a reusable rule and regression test; never replace the expected hash with a newly observed final hash without explaining the stage where it changed.

Run #4 is rejected: its metadata recorded the post-build `target/release/cline-app.exe` hash `430D6E5CDC831A19EECE82C642B79367DFC318785DCE738DC5DAA62E983968C3`, while the uploaded NSIS installer contained `44A38D48274571C1727CF129A1CB44D6412785833D0A35C4CC67696B26B56E62`. The #4 artifact has no build-stage snapshots, so the first App byte change cannot be proven retrospectively. Source inspection found a separate concrete bug: our path-scoped NSIS rebuild generated `nsis-output.exe` but never promoted it to the candidate installer path. The corrected cloud chain records every transition, promotes the repacked output, and refuses to upload a candidate if any payload change remains unexplained. Do not sign or release #4.

The signing key stays at `%USERPROFILE%\.tauri\cline-chinese-production\updater.key`; it is excluded from this package and from GitHub. Never put it in a GitHub secret or CI environment. The current formal installation and real `.cline`/WebView data are outside the build and publish scripts.

## After a candidate is submitted

Record the workflow URL/run ID and stop active monitoring. On a later turn, inspect the result once. If successful, the user runs the desktop shortcut once. The formal 0.0.33 to 0.0.34 transition must then be performed by the installed Desktop updater, followed by read-only continuity checks.
