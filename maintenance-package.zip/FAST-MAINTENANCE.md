# Cline Chinese fast maintenance

The production updater feed remains `https://github.com/439033521-maker/cline-desktop-zh-cn/releases/latest/download/latest.json`. The scheduled workflow compares that feed with the official stable Desktop feed every six hours. A newer stable release produces an **unsigned** Windows NSIS candidate and a report. GitHub Actions has no production updater private key, does not sign, and does not publish a stable Release.

The workflow reuses the official `desktop-v0.0.34` Windows toolchain/build order: Bun 1.3.13, Rust, UPX, SDK build, sidecar/remote-helper build, WebView build, Tauri NSIS. It adds the maintenance package migration and source checks before dependency installation. Known conflict hunks are recognized by content hash. An unknown hunk stops the job and uploads a small `agent-intervention` artifact containing the conflict slices and report. Bun and Rust caches are keyed by toolchain and upstream lockfiles; a Bun cache failure retries once without cache.

## 0.0.34 dry source rehearsal

- Official tag: `desktop-v0.0.34`; commit: `a094678c75ccabe63b0c2d3587e4c3a118f3a2f1`.
- 154 patch items: 55 added, 90 applied cleanly, 6 merged cleanly, 2 known conflicts, 1 lockfile regeneration. Automatic clean rate: 151/153 applicable source files, 98.7%.
- The manifest conflict is mechanical. The `use-chat-session.ts` conflict is semantic; the rule keeps upstream `formatRunError` and adds Chinese presentation at its new shared formatter.
- Source restoration, migration, known-conflict matching, static identity checks, and i18n key coverage passed without installing dependencies. Missing i18n keys: 0.
- Full cloud build, publish, and formal updater acceptance remain unverified until the workflow is committed and run.

## Local publishing

Run `SIGN-AND-PUBLISH.cmd` from this maintenance package, or use the desktop shortcut. It requires authenticated `gh`, Tauri CLI 2.x, and `minisign` as one-time local tools. The script downloads the newest successful candidate, checks version, official tag/commit, maintenance commit, gates, public key, and SHA-256; then asks for `PUBLISH` before signing. It passes only the local key **path** to the Tauri signer and suppresses signer output. The minisign verifier uses the public key independently. A draft Release is remotely checked before being marked Latest.

The signing key stays at `%USERPROFILE%\.tauri\cline-chinese-production\updater.key`; it is excluded from this package and from GitHub. Never put it in a GitHub secret or CI environment. The current formal installation and real `.cline`/WebView data are outside the build and publish scripts.

## After a candidate is submitted

Record the workflow URL/run ID and stop active monitoring. On a later turn, inspect the result once. If successful, the user runs the desktop shortcut once. The formal 0.0.33 to 0.0.34 transition must then be performed by the installed Desktop updater, followed by read-only continuity checks.
