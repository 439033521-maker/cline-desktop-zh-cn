"""Recreate the clean Cline Chinese 0.0.33 source baseline from official tar + overlay."""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
import tarfile
import zipfile
from pathlib import Path

if len(sys.argv) != 4:
    raise SystemExit("usage: restore_maintenance_source.py ARCHIVE.tar.gz MAINTENANCE_SOURCE_DIR OUTPUT_DIR")
archive_path, source_dir, output_dir = (Path(arg).resolve() for arg in sys.argv[1:])
manifest = json.loads((source_dir / "source-overlay-manifest.json").read_text(encoding="utf-8"))
if output_dir.exists():
    raise SystemExit(f"output already exists: {output_dir}")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


if digest(archive_path).upper() != manifest["upstreamArchiveSha256"]:
    raise SystemExit("official archive SHA-256 mismatch")
output_dir.mkdir(parents=True)
with tarfile.open(archive_path, "r:gz") as tar:
    for member in tar:
        parts = Path(member.name).parts
        if not parts or parts[0] != "cline-desktop-v0.0.33":
            raise SystemExit(f"unexpected archive root: {member.name}")
        rel = Path(*parts[1:])
        if not rel.parts:
            continue
        if ".." in rel.parts or member.isdev():
            raise SystemExit(f"unsafe archive member: {member.name}")
        if member.issym() or member.islnk():
            # Upstream contains documentation aliases; migration scans skip links.
            continue
        target = output_dir / rel
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
        elif member.isfile():
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as source, target.open("wb") as destination:
                shutil.copyfileobj(source, destination)
for rel in manifest["deleted"]:
    (output_dir / rel).unlink()
with zipfile.ZipFile(source_dir / "source-overlay.zip") as overlay:
    expected = set(manifest["added"] + manifest["modified"])
    if set(overlay.namelist()) != expected:
        raise SystemExit("overlay member list mismatch")
    for rel in sorted(expected):
        if Path(rel).is_absolute() or ".." in Path(rel).parts:
            raise SystemExit(f"unsafe overlay path: {rel}")
        target = output_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        with overlay.open(rel) as source, target.open("wb") as destination:
            shutil.copyfileobj(source, destination)
        if digest(target) != manifest["overlaySha256"][rel]:
            raise SystemExit(f"overlay SHA-256 mismatch: {rel}")
print(json.dumps({"restored": str(output_dir), "overlaid": len(expected), "deleted": len(manifest["deleted"])}))
