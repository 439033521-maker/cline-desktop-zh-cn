import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { assertTrace, fileIdentity, nsisScriptSource, patchNsisApp, replaceBundleType,
  restoreNsisApp, verifyCandidate } from './inspect-nsis-payload.mjs';

test('generated NSIS script resolves the actual App source and rejects a missing source', () => {
  const dir = mkdtempSync(join(tmpdir(), 'cline-nsis-source-test-'));
  try {
    const app = join(dir, 'cline-app.exe'), script = join(dir, 'installer.nsi');
    writeFileSync(app, 'real App payload');
    writeFileSync(script, `!define MAINBINARYSRCPATH "${app}"\n!define OUTFILE "nsis-output.exe"\nFile "\${MAINBINARYSRCPATH}"\n`);
    const parsed = nsisScriptSource(script);
    assert.equal(parsed.app.sha256, fileIdentity(app).sha256);
    assert.equal(parsed.app.bytes, fileIdentity(app).bytes);
    writeFileSync(script, '!define MAINBINARYSRCPATH "C:\\missing\\cline-app.exe"\n!define OUTFILE "nsis-output.exe"\nFile "${MAINBINARYSRCPATH}"\n');
    assert.throws(() => nsisScriptSource(script), /missing/);
  } finally {
    rmSync(dir, {recursive: true, force: true});
  }
});

test('Tauri NSIS bundle-type patch is the only allowed App transition', () => {
  const a = {sha256: 'A', bytes: 10}, b = {sha256: 'B', bytes: 10}, s = {sha256: 'S', bytes: 20};
  const trace = {preBundleApp: a, bundleInputApp: a, generatedNsisSource: {app: a},
    originalTauriInstaller: {app: b}, bundleTypePatch: {kind: 'tauri-nsis-bundle-type-patch', prePatchSha256: 'A', postPatchSha256: 'B'},
    patchedNsisSource: {app: b}, repackedNsis: {app: b, sidecar: s},
    finalInstaller: {app: b, sidecar: s}, preBundleSidecar: s, restoredApp: a};
  assert.doesNotThrow(() => assertTrace(trace));
  trace.originalTauriInstaller = {app: {sha256: 'DIFFERENT', bytes: 10}};
  assert.throws(() => assertTrace(trace), /lacks verified bundle-type patch evidence/);
  trace.originalTauriInstaller = {app: b};
  trace.finalInstaller = {app: b, sidecar: {sha256: 'DIFFERENT', bytes: 20}};
  assert.throws(() => assertTrace(trace), /sidecar repack promotion/);
});

test('the official UNK to NSS patch predicts initial makensis payload and restores original App', () => {
  const dir = mkdtempSync(join(tmpdir(), 'cline-nsis-patch-test-'));
  try {
    const app = join(dir, 'cline-app.exe'), script = join(dir, 'installer.nsi'), tracePath = join(dir, 'payload-trace.json');
    writeFileSync(app, 'prefix __TAURI_BUNDLE_TYPE_VAR_UNK suffix');
    writeFileSync(script, `!define MAINBINARYSRCPATH "${app}"\n!define OUTFILE "nsis-output.exe"\nFile "\${MAINBINARYSRCPATH}"\n`);
    const a = fileIdentity(app);
    const b = replaceBundleType(Buffer.from('prefix __TAURI_BUNDLE_TYPE_VAR_UNK suffix'),
      Buffer.from('__TAURI_BUNDLE_TYPE_VAR_UNK'), Buffer.from('__TAURI_BUNDLE_TYPE_VAR_NSS')).bytes;
    const expected = join(dir, 'expected.exe');
    writeFileSync(expected, b);
    const bHash = fileIdentity(expected);
    writeFileSync(tracePath, JSON.stringify({preBundleApp: a, originalTauriInstaller: {app: bHash}}));
    patchNsisApp(tracePath, script);
    const trace = JSON.parse(readFileSync(tracePath, 'utf8'));
    assert.equal(trace.patchedNsisSource.app.sha256, bHash.sha256);
    assert.equal(trace.bundleTypePatch.postPatchSha256, bHash.sha256);
    restoreNsisApp(tracePath, script);
    assert.equal(fileIdentity(app).sha256, a.sha256);
    writeFileSync(tracePath, JSON.stringify({preBundleApp: a, originalTauriInstaller: {app: {...bHash, sha256: 'WRONG'}}}));
    assert.throws(() => patchNsisApp(tracePath, script), /does not explain initial installer payload/);
    assert.equal(fileIdentity(app).sha256, a.sha256);
  } finally {
    rmSync(dir, {recursive: true, force: true});
  }
});

test('old candidate metadata without final payload hashes cannot pass local release gate', () => {
  const dir = mkdtempSync(join(tmpdir(), 'cline-nsis-schema-test-'));
  try {
    const metadata = join(dir, 'build-metadata.json');
    writeFileSync(metadata, JSON.stringify({app: {sha256: 'old-prebundle-hash'}, sidecar: {sha256: 'old-hash'}}));
    assert.throws(() => verifyCandidate(join(dir, 'candidate.exe'), metadata), /lacks final NSIS payload/);
  } finally {
    rmSync(dir, {recursive: true, force: true});
  }
});
