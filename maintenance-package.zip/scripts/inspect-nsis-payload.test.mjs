import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { assertTrace, fileIdentity, nsisScriptSource, verifyCandidate } from './inspect-nsis-payload.mjs';

test('generated NSIS script resolves the actual App source and rejects a missing source', () => {
  const dir = mkdtempSync(join(tmpdir(), 'cline-nsis-source-test-'));
  try {
    const app = join(dir, 'cline-app.exe'), script = join(dir, 'installer.nsi');
    writeFileSync(app, 'real App payload');
    writeFileSync(script, `!define MAINBINARYSRCPATH "${app}"\n!define OUTFILE "nsis-output.exe"\nFile "\${MAINBINARYSRCPATH}"\n`);
    const parsed = nsisScriptSource(script);
    assert.equal(parsed.app.sha256, fileIdentity(app).sha256);
    assert.equal(parsed.app.bytes, fileIdentity(app).bytes);
    writeFileSync(script, '!define MAINBINARYSRCPATH "C:\\missing\\cline-app.exe"\n!define OUTFILE "nsis-output.exe"\nFile "${MAINBINARYSRCPATH}"\n');
    assert.throws(() => nsisScriptSource(script), /missing/);
  } finally {
    rmSync(dir, {recursive: true, force: true});
  }
});

test('every build stage must preserve App and sidecar bytes', () => {
  const a = {sha256: 'A', bytes: 10}, s = {sha256: 'S', bytes: 20};
  const trace = {preBundleApp: a, bundleInputApp: a, generatedNsisSource: {app: a},
    originalTauriInstaller: {app: a}, patchedNsisSource: {app: a},
    repackedNsis: {app: a, sidecar: s}, finalInstaller: {app: a, sidecar: s},
    preBundleSidecar: s};
  assert.doesNotThrow(() => assertTrace(trace));
  trace.originalTauriInstaller = {app: {sha256: 'DIFFERENT', bytes: 10}};
  assert.throws(() => assertTrace(trace), /initial Tauri makensis payload/);
  trace.originalTauriInstaller = {app: a};
  trace.finalInstaller = {app: a, sidecar: {sha256: 'DIFFERENT', bytes: 20}};
  assert.throws(() => assertTrace(trace), /sidecar repack promotion/);
});

test('old candidate metadata without final payload hashes cannot pass local release gate', () => {
  const dir = mkdtempSync(join(tmpdir(), 'cline-nsis-schema-test-'));
  try {
    const metadata = join(dir, 'build-metadata.json');
    writeFileSync(metadata, JSON.stringify({app: {sha256: 'old-prebundle-hash'}, sidecar: {sha256: 'old-hash'}}));
    assert.throws(() => verifyCandidate(join(dir, 'candidate.exe'), metadata), /lacks final NSIS payload/);
  } finally {
    rmSync(dir, {recursive: true, force: true});
  }
});
