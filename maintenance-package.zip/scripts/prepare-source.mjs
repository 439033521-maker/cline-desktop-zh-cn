import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const [maintenanceArg, workArg, upstreamArg, archiveArg] = process.argv.slice(2);
if (![maintenanceArg, workArg, upstreamArg, archiveArg].every(Boolean))
  throw new Error('Usage: node prepare-source.mjs MAINTENANCE WORK UPSTREAM BASELINE_ARCHIVE');
const maintenance = resolve(maintenanceArg), work = resolve(workArg);
const upstream = resolve(upstreamArg), archive = resolve(archiveArg);
const source = join(maintenance, 'source'), phase = join(maintenance, 'pipeline', 'phase3');
const report = join(work, 'report'), run = join(work, 'migration');
const base = join(work, 'baseline'), localized = join(work, 'localized-baseline');
const resolved = join(work, 'resolved');
mkdirSync(report, {recursive: true});
const python = process.env.PYTHON || (process.platform === 'win32' ? 'py' : 'python3');
function step(name, command, args) {
  const started = Date.now();
  const result = spawnSync(command, args, {encoding: 'utf8', maxBuffer: 16 * 1024 * 1024});
  const seconds = Math.round((Date.now() - started) / 1000);
  const entry = {name, seconds, pass: result.status === 0};
  timings.push(entry);
  writeFileSync(join(report, 'timings.json'), JSON.stringify(timings, null, 2) + '\n');
  if (result.stdout) process.stdout.write(result.stdout.slice(-8000));
  if (result.stderr) process.stderr.write(result.stderr.slice(-8000));
  if (result.status !== 0) throw new Error(`${name} failed (exit ${result.status ?? 'unknown'})`);
}
const timings = [];
try {
  step('restore localized baseline', python, [join(source, 'restore_maintenance_source.py'), archive, source, localized]);
  const hash = JSON.parse(readFileSync(join(source, 'source-overlay-manifest.json'), 'utf8')).upstreamArchiveSha256;
  step('extract upstream baseline', python, [join(maintenance, 'scripts', 'extract_upstream.py'), archive, hash, base]);
  step('migration', 'node', [join(phase, 'auto-migrate.mjs'), base, localized, upstream, run]);
  step('extract conflicts', 'node', [join(phase, 'extract-conflicts.mjs'), run]);
  step('classify known conflicts', 'node', [join(phase, 'classify-known.mjs'), run, join(phase, 'known-conflicts.json')]);
  step('apply reviewed rules', 'node', [join(phase, 'resolve-generic.mjs'), run, localized, resolved]);
  step('static source gate', 'node', [join(maintenance, 'scripts', 'check-source.mjs'), resolved]);
  const outcomes = JSON.parse(readFileSync(join(run, 'first-pass-outcomes.json'), 'utf8'));
  const categories = JSON.parse(readFileSync(join(run, 'conflict-classification.json'), 'utf8'));
  const reportData = {upstreamVersion: JSON.parse(readFileSync(join(upstream, 'apps/examples/desktop-app/package.json'), 'utf8')).version,
    patchCount: outcomes.length, outcomes: Object.fromEntries([...new Set(outcomes.map(x => x.result))].map(k => [k, outcomes.filter(x => x.result === k).length])),
    conflicts: categories, resolved, timings};
  writeFileSync(join(report, 'migration-report.json'), JSON.stringify(reportData, null, 2) + '\n');
  console.log(`Migration ready: ${reportData.upstreamVersion}; ${outcomes.length} patches`);
} catch (error) {
  for (const name of ['first-pass-outcomes.json', 'patch-inventory.json', 'conflict-hunks.json', 'unknown-conflicts.json', 'conflict-classification.json']) {
    const path = join(run, name);
    if (existsSync(path)) cpSync(path, join(report, name));
  }
  writeFileSync(join(report, 'failure.txt'), String(error?.message ?? error) + '\n');
  process.exitCode = 1;
}
