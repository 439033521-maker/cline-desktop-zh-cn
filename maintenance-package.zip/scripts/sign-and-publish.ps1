$ErrorActionPreference = 'Stop'
$repo = '439033521-maker/cline-desktop-zh-cn'
$root = Split-Path $PSScriptRoot -Parent
$config = Get-Content -LiteralPath (Join-Path $root 'pipeline/production/release-config.json') -Raw | ConvertFrom-Json
$key = Join-Path $env:USERPROFILE '.tauri/cline-chinese-production/updater.key'
function NeedCommand([string]$name, [string]$message) {
  $command = Get-Command $name -ErrorAction SilentlyContinue
  if (-not $command) { throw $message }
  return $command.Source
}
$gh = NeedCommand 'gh' '一次性前置条件：请安装 GitHub CLI (gh) 并登录可发布此仓库的账户。'
$tauri = if ($env:TAURI_CLI) { $env:TAURI_CLI } else { NeedCommand 'tauri' '一次性前置条件：请安装 Tauri CLI 2.x，或将其完整路径设置为 TAURI_CLI。' }
$minisign = NeedCommand 'minisign' '一次性前置条件：请安装 minisign，用于独立验签。'
if (-not (Test-Path -LiteralPath $key -PathType Leaf)) { throw '本机 production updater private key 文件不存在。' }
& $gh auth status *> $null
if ($LASTEXITCODE -ne 0) { throw '一次性前置条件：请运行 gh auth login，授予当前账号该仓库 Release 发布权限。' }
function Api([string]$path) {
  $raw = & $gh api $path
  if ($LASTEXITCODE -ne 0) { throw "GitHub API 失败：$path" }
  return ($raw | ConvertFrom-Json)
}
function Semver([string]$value) {
  if ($value -notmatch '^([0-9]+)\.([0-9]+)\.([0-9]+)$') { throw "无效稳定版本：$value" }
  return [version]$value
}
function Sha([string]$path) { return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant() }
$listing = Api "repos/$repo/actions/artifacts?per_page=100"
$candidate = @($listing.artifacts | Where-Object { -not $_.expired -and $_.name -match '^cline-chinese-candidate-\d+\.\d+\.\d+-[0-9a-f]{12}$' } | Sort-Object created_at -Descending | Select-Object -First 1)
if ($candidate.Count -ne 1) { throw '没有可用的 GitHub Actions 成功候选产物。' }
$runId = [string]$candidate[0].workflow_run.id
$run = Api "repos/$repo/actions/runs/$runId"
if ($run.conclusion -ne 'success' -or $run.name -ne 'Cline Chinese fast maintenance candidate') { throw '候选产物的工作流未成功。' }
$stage = Join-Path $root 'publish-staging'
New-Item -ItemType Directory -Force -Path $stage | Out-Null
$download = Join-Path $stage "candidate-$runId"
if (Test-Path -LiteralPath $download) { throw "候选下载目录已存在，请检查后手动移走：$download" }
New-Item -ItemType Directory -Path $download | Out-Null
& $gh run download $runId --repo $repo --name $candidate[0].name --dir $download
if ($LASTEXITCODE -ne 0) { throw '候选下载失败。' }
$metadataPath = Join-Path $download 'build-metadata.json'
if (-not (Test-Path -LiteralPath $metadataPath)) { throw '构建元数据缺失。' }
$m = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
if ($m.signed -ne $false -or $m.productName -ne 'Cline Chinese' -or $m.identifier -ne 'bot.cline.app') { throw '候选身份或签名状态异常。' }
if ($m.updaterFeed -ne $config.httpsFeedUrl) { throw '候选 updater feed 与正式配置不同。' }
$hashAlgorithm = [Security.Cryptography.SHA256]::Create()
$publicHash = [BitConverter]::ToString($hashAlgorithm.ComputeHash([Text.Encoding]::UTF8.GetBytes($config.publicKey))).Replace('-', '')
$hashAlgorithm.Dispose()
if ($m.updaterPublicKeySha256 -ne $publicHash) { throw '候选内置 updater 公钥与正式配置不同。' }
foreach ($gate in 'migration','localization','typecheck','tests','sameSource','nsisIdentity') {
  if ($m.gates.$gate -ne 'PASS') { throw "候选门禁未通过：$gate" }
}
if ($m.upstreamTag -ne "desktop-v$($m.version)" -or $m.upstreamCommit -notmatch '^[0-9a-f]{40}$' -or $m.maintenanceCommit -ne $run.head_sha) { throw '上游/维护版本元数据异常。' }
$officialRef = Api "repos/cline/cline/git/ref/tags/$($m.upstreamTag)"
$officialSha = [string]$officialRef.object.sha
if ($officialRef.object.type -eq 'tag') { $officialSha = [string](Api "repos/cline/cline/git/tags/$officialSha").object.sha }
if ($officialSha -ne $m.upstreamCommit) { throw '候选上游 commit 与官方 tag 不符。' }
$artifact = Join-Path $download $m.artifact.name
if ((Sha $artifact) -ne $m.artifact.sha256 -or (Get-Item -LiteralPath $artifact).Length -ne $m.artifact.bytes) { throw '候选安装包 SHA-256/大小不符。' }
$current = Join-Path $env:LOCALAPPDATA 'Cline Chinese/cline-app.exe'
if (-not (Test-Path -LiteralPath $current)) { throw '当前正式 Cline Chinese 安装路径不存在。' }
$installedVersion = (Get-Item -LiteralPath $current).VersionInfo.ProductVersion
if ((Semver $m.version) -le (Semver $installedVersion)) { throw '候选版本不高于当前正式中文版。' }
$latest = Api "repos/$repo/releases/latest"
$tag = "v$($m.version)"
if ($latest.tag_name -eq $tag) { throw '同版本 Release 已是 Latest，拒绝重复发布。' }
Write-Host "上游：$($m.upstreamTag)  $($m.upstreamCommit)"
Write-Host "维护提交：$($m.maintenanceCommit)"
Write-Host "门禁：migration / localization / typecheck / tests / same-source / NSIS PASS"
Write-Host "安装包 SHA-256：$($m.artifact.sha256)"
Write-Host "当前：$installedVersion  候选：$($m.version)"
$answer = Read-Host '确认使用本机 production key 签名并发布？输入 PUBLISH'
if ($answer -cne 'PUBLISH') { throw '用户取消发布；未使用生产私钥。' }
$signaturePath = "$artifact.sig"
if (Test-Path -LiteralPath $signaturePath) { throw '候选签名文件已存在，拒绝覆盖。' }
& $tauri signer sign --private-key-path $key --password '' $artifact *> $null
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $signaturePath)) { throw 'Tauri 本机签名失败；输出已抑制。' }
$pubPath = Join-Path $download 'updater.pub'
$decodedSig = Join-Path $download 'artifact.minisig'
[IO.File]::WriteAllBytes($pubPath, [Convert]::FromBase64String($config.publicKey))
[IO.File]::WriteAllBytes($decodedSig, [Convert]::FromBase64String((Get-Content -LiteralPath $signaturePath -Raw).Trim()))
& $minisign -Vm $artifact -p $pubPath -x $decodedSig *> $null
if ($LASTEXITCODE -ne 0) { throw 'Production public key 独立验签失败。' }
$sig = (Get-Content -LiteralPath $signaturePath -Raw).Trim()
$url = "https://github.com/$repo/releases/download/$tag/$($m.artifact.name)"
$entry = @{ url=$url; signature=$sig }
$manifest = @{version=$m.version; notes="Cline Chinese $($m.version): official Desktop $($m.version) core with Simplified Chinese UI and default Chinese responses.";
  pub_date=[DateTime]::UtcNow.ToString('o'); platforms=@{'windows-x86_64-nsis'=$entry; 'windows-x86_64'=$entry}}
$manifestPath = Join-Path $download 'latest.json'
[IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
$sumPath = Join-Path $download 'SHA256SUMS.txt'
"$($m.artifact.sha256)  $($m.artifact.name)" | Set-Content -LiteralPath $sumPath -Encoding ascii
$notesPath = Join-Path $download 'RELEASE-NOTES.md'
"Cline Chinese $($m.version)`n`nUpstream: $($m.upstreamTag) ($($m.upstreamCommit))`nMaintenance: $($m.maintenanceCommit)`nAll cloud gates PASS; locally signed with the production updater key.`n" | Set-Content -LiteralPath $notesPath -Encoding utf8
& $gh release view $tag --repo $repo *> $null
if ($LASTEXITCODE -eq 0) { throw '目标 Release 已存在，拒绝覆盖。' }
& $gh release create $tag $artifact $signaturePath $manifestPath $sumPath $metadataPath --repo $repo --target main --title "Cline Chinese Desktop $($m.version)" --notes-file $notesPath --draft
if ($LASTEXITCODE -ne 0) { throw '草稿 Release 上传失败；请检查草稿，勿重新签名。' }
$draftVerify = Join-Path $download 'remote-draft'
New-Item -ItemType Directory -Path $draftVerify | Out-Null
& $gh release download $tag --repo $repo --dir $draftVerify --pattern $m.artifact.name --pattern "$($m.artifact.name).sig" --pattern 'latest.json'
if ($LASTEXITCODE -ne 0 -or (Sha (Join-Path $draftVerify $m.artifact.name)) -ne $m.artifact.sha256) { throw '草稿远端 hash 不一致；保持草稿状态。' }
if ((Get-Content -LiteralPath (Join-Path $draftVerify "$($m.artifact.name).sig") -Raw).Trim() -ne $sig) { throw '草稿远端签名与本机签名不同。' }
& $minisign -Vm (Join-Path $draftVerify $m.artifact.name) -p $pubPath -x $decodedSig *> $null
if ($LASTEXITCODE -ne 0) { throw '草稿远端安装包验签失败；保持草稿状态。' }
& $gh release edit $tag --repo $repo --draft=false --latest
if ($LASTEXITCODE -ne 0) { throw 'Release 发布失败；检查草稿状态。' }
$stable = Api "repos/$repo/releases/latest"
if ($stable.tag_name -ne $tag) { throw 'Release 未成为 Latest。' }
$stableVerify = Join-Path $download 'remote-stable'
New-Item -ItemType Directory -Path $stableVerify | Out-Null
& $gh release download $tag --repo $repo --dir $stableVerify --pattern 'latest.json'
if ($LASTEXITCODE -ne 0) { throw '无法从 Latest Release 重新下载 manifest。' }
$remoteManifest = Get-Content -LiteralPath (Join-Path $stableVerify 'latest.json') -Raw | ConvertFrom-Json
if ($remoteManifest.version -ne $m.version -or $remoteManifest.platforms.'windows-x86_64-nsis'.url -ne $url -or $remoteManifest.platforms.'windows-x86_64-nsis'.signature -ne $sig) { throw '远端 manifest 版本/URL/签名不一致。' }
Write-Host "发布成功 — Cline Chinese $($m.version)"
Write-Host "https://github.com/$repo/releases/tag/$tag"
