import { readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const [maintenanceArg, sourceArg] = process.argv.slice(2);
if (!maintenanceArg || !sourceArg) throw new Error('Usage: node create-candidate-config.mjs MAINTENANCE SOURCE');
const maintenance = resolve(maintenanceArg), source = resolve(sourceArg);
const config = JSON.parse(readFileSync(join(maintenance, 'pipeline/production/release-config.json'), 'utf8'));
const version = JSON.parse(readFileSync(join(source, 'apps/examples/desktop-app/package.json'), 'utf8')).version;
if (!/^\d+\.\d+\.\d+$/.test(version) || !config.httpsFeedUrl.startsWith('https://github.com/439033521-maker/cline-desktop-zh-cn/'))
  throw new Error('Candidate version or feed is invalid');
const overlay = {productName: 'Cline Chinese', version, identifier: 'bot.cline.app',
  plugins: {updater: {pubkey: config.publicKey, endpoints: [config.httpsFeedUrl]}},
  bundle: {targets: ['nsis'], createUpdaterArtifacts: false}};
const path = join(source, 'apps/examples/desktop-app/src-tauri/tauri.chinese-candidate.conf.json');
writeFileSync(path, JSON.stringify(overlay, null, 2) + '\n');
console.log(path);
