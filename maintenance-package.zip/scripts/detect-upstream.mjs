const repo = '439033521-maker/cline-desktop-zh-cn';
const officialFeed = 'https://github.com/cline/cline/releases/download/desktop-latest/latest.json';
const chineseFeed = `https://github.com/${repo}/releases/latest/download/latest.json`;
async function json(url, headers = {}) {
  const response = await fetch(url, {headers: {'User-Agent': 'Cline-Chinese-Maintenance', ...headers}, redirect: 'follow'});
  if (!response.ok) throw new Error(`${url}: HTTP ${response.status}`);
  return response.json();
}
function version(value) {
  if (!/^\d+\.\d+\.\d+$/.test(value ?? '')) throw new Error(`Not a stable Desktop version: ${value}`);
  return value.split('.').map(Number);
}
function compare(a, b) {
  const x = version(a), y = version(b);
  for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] - y[i];
  return 0;
}
const official = (await json(officialFeed)).version;
const chinese = (await json(chineseFeed)).version;
const requested = process.env.REQUESTED_VERSION?.trim();
const next = requested || official;
if (requested && compare(next, official) > 0) throw new Error('Requested version is newer than official stable feed');
const tag = `desktop-v${next}`;
const release = await json(`https://api.github.com/repos/cline/cline/releases/tags/${tag}`);
if (release.prerelease || release.draft || !/^desktop-v\d+\.\d+\.\d+$/.test(release.tag_name))
  throw new Error('Official release is not stable');
const shouldBuild = compare(next, chinese) > 0;
const maintenanceCommit = process.env.GITHUB_SHA?.slice(0, 12) ?? 'local';
const artifactName = `cline-chinese-candidate-${next}-${maintenanceCommit}`;
let duplicate = false;
if (shouldBuild && process.env.GITHUB_TOKEN && !process.env.FORCE_BUILD) {
  const data = await json(`https://api.github.com/repos/${repo}/actions/artifacts?name=${encodeURIComponent(artifactName)}&per_page=100`,
    {Authorization: `Bearer ${process.env.GITHUB_TOKEN}`, Accept: 'application/vnd.github+json'});
  duplicate = data.artifacts?.some(item => !item.expired) ?? false;
}
const build = shouldBuild && (!duplicate || process.env.FORCE_BUILD === 'true');
const output = {official, chinese, version: next, tag, build: String(build), artifactName,
  reason: !shouldBuild ? 'no-newer-upstream' : duplicate && !build ? 'candidate-already-exists' : 'new-stable'};
if (process.env.GITHUB_OUTPUT) {
  const fs = await import('node:fs');
  fs.appendFileSync(process.env.GITHUB_OUTPUT, Object.entries(output).map(([key, value]) => `${key}=${value}`).join('\n') + '\n');
}
console.log(JSON.stringify(output));
