import { createHash } from 'node:crypto';
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { basename, join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const [sourceArg, outArg, maintenanceCommit] = process.argv.slice(2);
if (!sourceArg || !outArg || !maintenanceCommit) throw new Error('Usage: node collect-candidate.mjs SOURCE OUT MAINTENANCE_COMMIT');
const source = resolve(sourceArg), out = resolve(outArg);
const app = join(source, 'apps/examples/desktop-app');
const version = JSON.parse(readFileSync(join(app, 'package.json'), 'utf8')).version;
const overlay = JSON.parse(readFileSync(join(app, 'src-tauri/tauri.chinese-candidate.conf.json'), 'utf8'));
if (overlay.productName !== 'Cline Chinese' || overlay.identifier !== 'bot.cline.app' || overlay.version !== version ||
    overlay.bundle.createUpdaterArtifacts !== false) throw new Error('Candidate install/updater identity mismatch');
const bundle = join(app, 'src-tauri/target/release/bundle/nsis');
const installers = readdirSync(bundle).filter(x => x.endsWith('-setup.exe'));
if (installers.length !== 1) throw new Error(`Expected one NSIS installer, found ${installers.length}`);
const installer = join(bundle, installers[0]);
if (existsSync(installer + '.sig')) throw new Error('Cloud candidate unexpectedly has updater signature');
const builtApp = join(app, 'src-tauri/target/release/cline-app.exe');
const sidecar = join(app, 'src-tauri/bin/code-sidecar-x86_64-pc-windows-msvc.exe');
for (const path of [installer, builtApp, sidecar])
  if (!existsSync(path) || statSync(path).size < 1_000_000) throw new Error(`Build output missing: ${path}`);
const git = spawnSync('git', ['-C', source, 'rev-parse', 'HEAD'], {encoding: 'utf8'});
const upstreamCommit = process.env.UPSTREAM_COMMIT || git.stdout.trim();
if (!/^[0-9a-f]{40}$/.test(upstreamCommit)) throw new Error('Upstream commit missing');
const sha256 = path => createHash('sha256').update(readFileSync(path)).digest('hex').toUpperCase();
mkdirSync(out, {recursive: true});
const name = `Cline-Chinese_${version}_x64-setup.exe`;
copyFileSync(installer, join(out, name));
const metadata = {version, upstreamTag: `desktop-v${version}`, upstreamCommit, maintenanceCommit,
  productName: overlay.productName, identifier: overlay.identifier,
  updaterFeed: overlay.plugins.updater.endpoints[0],
  updaterPublicKeySha256: createHash('sha256').update(overlay.plugins.updater.pubkey).digest('hex').toUpperCase(),
  artifact: {name, sha256: sha256(installer), bytes: statSync(installer).size},
  app: {sha256: sha256(builtApp)}, sidecar: {sha256: sha256(sidecar)},
  gates: {migration: 'PASS', localization: 'PASS', typecheck: 'PASS', tests: 'PASS', sameSource: 'PASS', nsisIdentity: 'PASS'},
  signed: false};
writeFileSync(join(out, 'build-metadata.json'), JSON.stringify(metadata, null, 2) + '\n');
console.log(`Unsigned candidate ${name} SHA-256 ${metadata.artifact.sha256}`);
