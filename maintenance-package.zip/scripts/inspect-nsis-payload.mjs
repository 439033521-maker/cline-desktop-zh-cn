import { createHash } from 'node:crypto';
import { existsSync, mkdtempSync, readFileSync, realpathSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { basename, dirname, isAbsolute, join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const sha256 = path => createHash('sha256').update(readFileSync(path)).digest('hex').toUpperCase();
export const fileIdentity = path => {
  const full = realpathSync(path);
  if (!statSync(full).isFile()) throw new Error(`Not a regular file: ${full}`);
  return {path: full, bytes: statSync(full).size, sha256: sha256(full)};
};

const unbundledToken = Buffer.from('__TAURI_BUNDLE_TYPE_VAR_UNK');
const nsisToken = Buffer.from('__TAURI_BUNDLE_TYPE_VAR_NSS');
if (unbundledToken.length !== nsisToken.length) throw new Error('Tauri bundle type tokens have different lengths');

export function replaceBundleType(buffer, from, to) {
  const index = buffer.indexOf(from);
  if (index < 0 || buffer.indexOf(from, index + from.length) >= 0) {
    throw new Error('Expected exactly one Tauri bundle type token in App executable');
  }
  const result = Buffer.from(buffer);
  to.copy(result, index);
  return {bytes: result, offset: index};
}

export function patchNsisApp(tracePath, scriptPath) {
  const trace = JSON.parse(readFileSync(tracePath, 'utf8'));
  const source = nsisScriptSource(scriptPath);
  if (source.app.path !== trace.preBundleApp?.path || source.app.sha256 !== trace.preBundleApp?.sha256) {
    throw new Error('NSIS source is not the recorded pre-bundle App');
  }
  const patched = replaceBundleType(readFileSync(source.app.path), unbundledToken, nsisToken);
  const patchedHash = createHash('sha256').update(patched.bytes).digest('hex').toUpperCase();
  if (patchedHash !== trace.originalTauriInstaller?.app?.sha256 ||
      patched.bytes.length !== trace.originalTauriInstaller?.app?.bytes) {
    throw new Error('Tauri NSIS bundle-type patch does not explain initial installer payload hash');
  }
  writeFileSync(source.app.path, patched.bytes);
  trace.bundleTypePatch = {kind: 'tauri-nsis-bundle-type-patch', sourcePath: source.app.path,
    offset: patched.offset, prePatchSha256: source.app.sha256, postPatchSha256: patchedHash,
    replacement: nsisToken.toString('ascii')};
  trace.patchedNsisSource = nsisScriptSource(scriptPath);
  writeFileSync(tracePath, JSON.stringify(trace, null, 2) + '\n');
}

export function restoreNsisApp(tracePath, scriptPath) {
  const trace = JSON.parse(readFileSync(tracePath, 'utf8'));
  const source = nsisScriptSource(scriptPath);
  if (source.app.sha256 !== trace.bundleTypePatch?.postPatchSha256 ||
      source.app.path !== trace.bundleTypePatch?.sourcePath) {
    throw new Error('Patched App changed before Tauri bundle-type restoration');
  }
  const restored = replaceBundleType(readFileSync(source.app.path), nsisToken, unbundledToken);
  const restoredHash = createHash('sha256').update(restored.bytes).digest('hex').toUpperCase();
  if (restoredHash !== trace.preBundleApp.sha256 || restored.offset !== trace.bundleTypePatch.offset) {
    throw new Error('Tauri bundle-type restoration does not reproduce pre-bundle App');
  }
  writeFileSync(source.app.path, restored.bytes);
  trace.restoredApp = fileIdentity(source.app.path);
  writeFileSync(tracePath, JSON.stringify(trace, null, 2) + '\n');
}

export function nsisScriptSource(scriptPath) {
  const source = readFileSync(scriptPath, 'utf8');
  const main = source.match(/^\s*!define\s+MAINBINARYSRCPATH\s+"([^"]+)"/m);
  const output = source.match(/^\s*!define\s+OUTFILE\s+"([^"]+)"/m);
  if (!main || !output || !source.includes('File "${MAINBINARYSRCPATH}"')) {
    throw new Error('Generated NSIS script does not identify its main executable payload');
  }
  const payloadPath = main[1].replaceAll('\\\\', '\\');
  if (!isAbsolute(payloadPath) || !existsSync(payloadPath)) {
    throw new Error(`NSIS main binary source is missing: ${payloadPath}`);
  }
  if (basename(output[1]).toLowerCase() !== 'nsis-output.exe') {
    throw new Error(`Unexpected NSIS output name: ${output[1]}`);
  }
  return {script: realpathSync(scriptPath), outputName: output[1], app: fileIdentity(payloadPath)};
}

function sevenZip() {
  const candidates = [process.env.SEVEN_ZIP_PATH, 'C:\\Program Files\\7-Zip\\7z.exe', '7z'].filter(Boolean);
  for (const candidate of candidates) {
    const probe = spawnSync(candidate, ['-h'], {stdio: 'ignore', windowsHide: true});
    if (probe.status === 0) return candidate;
  }
  throw new Error('7-Zip is required to inspect the final NSIS payload');
}

export function inspectInstaller(installerPath) {
  const installer = fileIdentity(installerPath);
  const dir = mkdtempSync(join(dirname(installer.path), '.payload-audit-'));
  try {
    const result = spawnSync(sevenZip(), ['x', '-y', `-o${dir}`, installer.path, 'cline-app.exe', 'code-sidecar.exe'],
      {encoding: 'utf8', windowsHide: true, maxBuffer: 1024 * 1024});
    if (result.status !== 0) throw new Error(`7-Zip could not extract NSIS payload (exit ${result.status})`);
    const app = join(dir, 'cline-app.exe'), sidecar = join(dir, 'code-sidecar.exe');
    if (!existsSync(app) || !existsSync(sidecar)) throw new Error('NSIS App or sidecar payload is missing');
    return {installer: {bytes: installer.bytes, sha256: installer.sha256},
      app: {bytes: statSync(app).size, sha256: sha256(app)},
      sidecar: {bytes: statSync(sidecar).size, sha256: sha256(sidecar)}};
  } finally {
    rmSync(dir, {recursive: true, force: true});
  }
}

export function assertTrace(trace) {
  const equal = (a, b, label) => {
    if (!a?.sha256 || !b?.sha256 || a.sha256 !== b.sha256 || a.bytes !== b.bytes) {
      throw new Error(`Unexplained App/sidecar transformation at ${label}; see payload-trace.json`);
    }
  };
  equal(trace.preBundleApp, trace.bundleInputApp, 'before Tauri bundling');
  equal(trace.bundleInputApp, trace.generatedNsisSource.app, 'Tauri bundle source selection');
  if (trace.bundleTypePatch?.kind !== 'tauri-nsis-bundle-type-patch' ||
      trace.bundleTypePatch.prePatchSha256 !== trace.preBundleApp.sha256 ||
      trace.bundleTypePatch.postPatchSha256 !== trace.originalTauriInstaller?.app?.sha256) {
    throw new Error('Initial Tauri NSIS payload lacks verified bundle-type patch evidence');
  }
  equal(trace.originalTauriInstaller.app, trace.patchedNsisSource.app, 'custom NSIS patch source');
  equal(trace.patchedNsisSource.app, trace.repackedNsis.app, 'makensis payload');
  equal(trace.repackedNsis.app, trace.finalInstaller.app, 'repack promotion');
  equal(trace.preBundleApp, trace.restoredApp, 'post-bundle App restoration');
  equal(trace.preBundleSidecar, trace.repackedNsis.sidecar, 'sidecar packaging');
  equal(trace.repackedNsis.sidecar, trace.finalInstaller.sidecar, 'sidecar repack promotion');
}

export function verifyCandidate(installerPath, metadataPath) {
  const m = JSON.parse(readFileSync(metadataPath, 'utf8'));
  if (m.payloadSchema !== 1 || !m.app?.preBundleSha256 || !m.app?.finalInstallerPayloadSha256 ||
      !m.sidecar?.finalInstallerPayloadSha256 || !m.artifact?.sha256) {
    throw new Error('Candidate metadata lacks final NSIS payload integrity fields');
  }
  const actual = inspectInstaller(installerPath);
  if (actual.installer.sha256 !== m.artifact.sha256 || actual.installer.bytes !== m.artifact.bytes ||
      actual.app.sha256 !== m.app.finalInstallerPayloadSha256 || actual.app.bytes !== m.app.finalInstallerPayloadBytes ||
      actual.sidecar.sha256 !== m.sidecar.finalInstallerPayloadSha256 || actual.sidecar.bytes !== m.sidecar.finalInstallerPayloadBytes) {
    throw new Error('Final NSIS payload differs from cloud candidate metadata');
  }
  return actual;
}

function updateTrace(reportPath, stage, value) {
  const trace = existsSync(reportPath) ? JSON.parse(readFileSync(reportPath, 'utf8')) : {};
  trace[stage] = value;
  writeFileSync(reportPath, JSON.stringify(trace, null, 2) + '\n');
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [command, first, second, third] = process.argv.slice(2);
  if (command === 'record-file' && first && second && third) {
    updateTrace(first, second, fileIdentity(third));
  } else if (command === 'record-script' && first && second && third) {
    updateTrace(first, second, nsisScriptSource(third));
  } else if (command === 'record-installer' && first && second && third) {
    updateTrace(first, second, inspectInstaller(third));
  } else if (command === 'patch-nsis-app' && first && second) {
    patchNsisApp(first, second);
  } else if (command === 'restore-nsis-app' && first && second) {
    restoreNsisApp(first, second);
  } else if (command === 'verify' && first && second) {
    verifyCandidate(first, second);
    console.log('FINAL_NSIS_PAYLOAD=PASS');
  } else {
    throw new Error('Usage: inspect-nsis-payload.mjs record-file|record-script|record-installer TRACE STAGE PATH | patch-nsis-app|restore-nsis-app TRACE NSI | verify INSTALLER METADATA');
  }
}
