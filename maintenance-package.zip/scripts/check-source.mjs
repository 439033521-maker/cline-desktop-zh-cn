import { readFileSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve(process.argv[2] ?? '');
if (!process.argv[2]) throw new Error('Usage: node check-source.mjs RESOLVED_SOURCE');
const read = path => readFileSync(join(root, path), 'utf8');
const app = JSON.parse(read('apps/examples/desktop-app/package.json'));
const tauri = JSON.parse(read('apps/examples/desktop-app/src-tauri/tauri.conf.json'));
if (app.version !== tauri.version || !/^\d+\.\d+\.\d+$/.test(app.version))
  throw new Error('Desktop package/Tauri versions differ or are prerelease');
for (const dep of ['i18next', 'react-i18next'])
  if (!app.dependencies?.[dep]) throw new Error(`Chinese dependency missing: ${dep}`);
for (const script of ['i18n:check', 'i18n:coverage'])
  if (!app.scripts?.[script]) throw new Error(`Chinese script missing: ${script}`);
const mustContain = [
  ['sdk/packages/shared/src/prompt/system/index.ts', 'OUTPUT_LANGUAGE_INSTRUCTIONS'],
  ['sdk/packages/shared/src/prompt/cline.ts', 'appendOutputLanguagePolicy'],
  ['sdk/packages/core/src/runtime/orchestration/session-runtime-orchestrator.ts', 'ensureOutputLanguagePolicyLast'],
  ['apps/examples/desktop-app/src-tauri/nsis/installer-hooks.nsh', 'code-sidecar'],
  ['apps/examples/desktop-app/src-tauri/vendor/tauri-plugin-single-instance/src/platform_impl/windows.rs', 'Cline Chinese'],
];
for (const [path, text] of mustContain)
  if (!existsSync(join(root, path)) || !read(path).includes(text))
    throw new Error(`Chinese identity/prompt hook missing: ${path}`);
const agent = JSON.parse(read('apps/examples/desktop-app/webview/i18n/locales/zh-CN/agent-chat.json'));
for (const key of ['Thought for {{seconds}}s', 'Ran {{n}} commands', 'Read {{n}} files'])
  if (!agent[key] || !/[\u3400-\u9fff]/.test(agent[key])) throw new Error(`Agent status translation missing: ${key}`);
const common = JSON.parse(read('apps/examples/desktop-app/webview/i18n/locales/zh-CN/common.json'));
for (const key of ['Update ready: v{{version}}', 'The run failed'])
  if (!common[key] || !/[\u3400-\u9fff]/.test(common[key])) throw new Error(`UI translation missing: ${key}`);
console.log(`Static Chinese source gate PASS for ${app.version}`);
