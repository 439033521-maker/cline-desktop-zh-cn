"""Extract a fresh official source archive on Windows, skipping Unix symlinks."""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
import tarfile
from pathlib import Path

if len(sys.argv) != 4:
    raise SystemExit("usage: extract_upstream.py ARCHIVE.tar.gz EXPECTED_SHA256 OUTPUT_DIR")
archive, expected_hash, destination = (Path(sys.argv[1]).resolve(), sys.argv[2].upper(), Path(sys.argv[3]).resolve())
if destination.exists():
    raise SystemExit(f"destination already exists: {destination}")
h = hashlib.sha256()
with archive.open("rb") as stream:
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        h.update(chunk)
if h.hexdigest().upper() != expected_hash:
    raise SystemExit("source archive SHA-256 mismatch")
destination.mkdir(parents=True)
root_name = None
files = 0
skipped_links = 0
with tarfile.open(archive, "r:gz") as tar:
    for member in tar:
        parts = Path(member.name).parts
        if not parts:
            continue
        if root_name is None:
            root_name = parts[0]
        if parts[0] != root_name:
            raise SystemExit("archive has multiple roots")
        rel = Path(*parts[1:])
        if not rel.parts:
            continue
        if ".." in rel.parts or member.isdev():
            raise SystemExit(f"unsafe archive member: {member.name}")
        if member.issym() or member.islnk():
            skipped_links += 1
            continue
        target = destination / rel
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
        elif member.isfile():
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            files += 1
print(json.dumps({"archiveRoot": root_name, "files": files, "skippedUnixLinks": skipped_links, "destination": str(destination)}))
