// Fail fast if the maintenance build starts the root Vitest project graph for
// two focused Agent prompt tests. Each package owns its own Vitest config.
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const [maintenanceArg, sourceArg] = process.argv.slice(2);
if (!maintenanceArg || !sourceArg)
  throw new Error('Usage: node check-agent-test-selection.mjs MAINTENANCE SOURCE');
const maintenance = resolve(maintenanceArg);
const source = resolve(sourceArg);
const build = readFileSync(join(maintenance, 'scripts/run-build.ps1'), 'utf8');
const stage = build.match(/Stage 'localization and Agent tests' \{([\s\S]*?)\nStage 'install identity test'/)?.[1];
assert.ok(stage, 'Agent test stage is missing');
assert.doesNotMatch(stage, /bunx vitest run sdk\/packages\//,
  'Agent tests must not be launched from the root workspace');

for (const target of [
  { variable: 'shared', directory: 'sdk/packages/shared', test: 'src/prompt/cline.test.ts' },
  { variable: 'core', directory: 'sdk/packages/core', test: 'src/runtime/orchestration/session-runtime-orchestrator.test.ts' },
]) {
  const packageRoot = join(source, target.directory);
  const config = join(packageRoot, 'vitest.config.ts');
  assert.ok(existsSync(join(packageRoot, target.test)), `Missing Agent test: ${target.directory}/${target.test}`);
  assert.ok(existsSync(config), `Missing package Vitest config: ${config}`);
  assert.doesNotMatch(readFileSync(config, 'utf8'), /\bprojects\s*:/,
    `${target.directory} config unexpectedly loads a project graph`);
  const escapedTest = target.test.replaceAll(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const command = new RegExp(`Push-Location \\$${target.variable}[\\s\\S]*?bunx vitest run ${escapedTest} --config vitest\\.config\\.ts`);
  assert.match(stage, command, `${target.directory} must run its focused test under its package config`);
}
console.log('Agent prompt test selection: package-scoped configs and both focused tests verified');
