param(
  [Parameter(Mandatory=$true)][string]$Maintenance,
  [Parameter(Mandatory=$true)][string]$Work,
  [Parameter(Mandatory=$true)][string]$UpstreamCommit,
  [Parameter(Mandatory=$true)][string]$MaintenanceCommit
)
$ErrorActionPreference = 'Stop'
$source = Join-Path $Work 'resolved'
$app = Join-Path $source 'apps/examples/desktop-app'
$shared = Join-Path $source 'sdk/packages/shared'
$core = Join-Path $source 'sdk/packages/core'
$report = Join-Path $Work 'report'
$candidate = Join-Path $Work 'candidate'
$payloadTrace = Join-Path $report 'payload-trace.json'
$payloadInspector = Join-Path $Maintenance 'scripts/inspect-nsis-payload.mjs'
New-Item -ItemType Directory -Force -Path $report,$candidate | Out-Null
$stages = @()
function Stage([string]$name, [scriptblock]$body) {
  $watch = [Diagnostics.Stopwatch]::StartNew()
  try {
    & $body
    $script:stages += [pscustomobject]@{stage=$name; seconds=[math]::Round($watch.Elapsed.TotalSeconds,1); pass=$true}
  } catch {
    $script:stages += [pscustomobject]@{stage=$name; seconds=[math]::Round($watch.Elapsed.TotalSeconds,1); pass=$false}
    $stages | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $report 'build-timings.json') -Encoding utf8
    throw
  }
  $stages | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $report 'build-timings.json') -Encoding utf8
}
if ($env:TAURI_SIGNING_PRIVATE_KEY -or $env:TAURI_SIGNING_PRIVATE_KEY_PATH) { throw 'Production updater signing key must not exist in cloud build environment' }
Stage 'dependency install' {
  Push-Location $source
  try {
    bun install
    if ($LASTEXITCODE -ne 0) {
      bun install --no-cache
      if ($LASTEXITCODE -ne 0) { throw 'Bun clean-install fallback failed' }
    }
  } finally { Pop-Location }
}
Stage 'SDK/Hub shared build' {
  Push-Location $source
  try { bun run build:sdk; if ($LASTEXITCODE -ne 0) { throw 'SDK build failed' } }
  finally { Pop-Location }
}
Stage 'typecheck' {
  Push-Location $app
  try { bun run typecheck; if ($LASTEXITCODE -ne 0) { throw 'Desktop typecheck failed' } }
  finally { Pop-Location }
}
Stage 'localization and Agent tests' {
  Push-Location $app
  try {
    bunx vitest run webview/i18n/agent-chat.test.ts webview/lib/run-error.zh.test.ts webview/hooks/use-app-update.test.tsx --config vitest.config.ts
    if ($LASTEXITCODE -ne 0) { throw 'Desktop Chinese tests failed' }
  } finally { Pop-Location }
  Push-Location $shared
  try {
    bunx vitest run src/prompt/cline.test.ts --config vitest.config.ts
    if ($LASTEXITCODE -ne 0) { throw 'Shared Agent prompt tests failed' }
  } finally { Pop-Location }
  Push-Location $core
  try {
    bunx vitest run src/runtime/orchestration/session-runtime-orchestrator.test.ts --config vitest.config.ts
    if ($LASTEXITCODE -ne 0) { throw 'Core Agent prompt tests failed' }
  } finally { Pop-Location }
}
Stage 'install identity test' {
  Push-Location $app
  try {
    bun run test:windows-installer
    if ($LASTEXITCODE -ne 0) { throw 'NSIS path-scoped process test failed' }
  } finally { Pop-Location }
}
Stage 'Rust/Tauri and WebView/sidecar build' {
  Push-Location $app
  try {
    bunx tauri build --no-bundle --config src-tauri/tauri.chinese-candidate.conf.json
    if ($LASTEXITCODE -ne 0) { throw 'Tauri build failed' }
  } finally { Pop-Location }
  node $payloadInspector record-file $payloadTrace preBundleApp (Join-Path $app 'src-tauri/target/release/cline-app.exe')
  if ($LASTEXITCODE -ne 0) { throw 'Pre-bundle App hash capture failed' }
  node $payloadInspector record-file $payloadTrace preBundleSidecar (Join-Path $app 'src-tauri/bin/code-sidecar-x86_64-pc-windows-msvc.exe')
  if ($LASTEXITCODE -ne 0) { throw 'Pre-bundle sidecar hash capture failed' }
}
Stage 'Tauri NSIS bundling and input trace' {
  node $payloadInspector record-file $payloadTrace bundleInputApp (Join-Path $app 'src-tauri/target/release/cline-app.exe')
  if ($LASTEXITCODE -ne 0) { throw 'Bundle input hash capture failed' }
  Push-Location $app
  try {
    bunx tauri bundle --bundles nsis --config src-tauri/tauri.chinese-candidate.conf.json
    if ($LASTEXITCODE -ne 0) { throw 'Tauri NSIS bundle failed' }
  } finally { Pop-Location }
  $scripts = @(Get-ChildItem -LiteralPath (Join-Path $app 'src-tauri/target/release/nsis') -Recurse -Filter installer.nsi -File)
  if ($scripts.Count -ne 1) { throw "Expected one generated installer.nsi, found $($scripts.Count)" }
  node $payloadInspector record-script $payloadTrace generatedNsisSource $scripts[0].FullName
  if ($LASTEXITCODE -ne 0) { throw 'Generated NSIS source trace failed' }
  $installers = @(Get-ChildItem -LiteralPath (Join-Path $app 'src-tauri/target/release/bundle/nsis') -Filter '*-setup.exe' -File)
  if ($installers.Count -ne 1) { throw "Expected one Tauri NSIS installer, found $($installers.Count)" }
  node $payloadInspector record-installer $payloadTrace originalTauriInstaller $installers[0].FullName
  if ($LASTEXITCODE -ne 0) { throw 'Original Tauri NSIS payload trace failed' }
}
Stage 'path-scoped NSIS repackaging' {
  $scripts = @(Get-ChildItem -LiteralPath (Join-Path $app 'src-tauri/target/release/nsis') -Recurse -Filter installer.nsi -File)
  if ($scripts.Count -ne 1) { throw "Expected one generated installer.nsi, found $($scripts.Count)" }
  node (Join-Path $Maintenance 'pipeline/phase2/patch-nsis.mjs') $scripts[0].FullName 'Cline Chinese'
  if ($LASTEXITCODE -ne 0) { throw 'NSIS process scope patch failed' }
  node $payloadInspector patch-nsis-app $payloadTrace $scripts[0].FullName
  if ($LASTEXITCODE -ne 0) { throw 'Tauri NSIS bundle-type patch does not explain initial payload' }
  $nsisDir = Split-Path $scripts[0].FullName -Parent
  $repacked = Join-Path $nsisDir 'nsis-output.exe'
  if (Test-Path -LiteralPath $repacked) { throw 'Stale NSIS repack output exists' }
  try {
    Push-Location $nsisDir
    try {
      & $env:MAKENSIS_PATH '/V3' $scripts[0].FullName
      if ($LASTEXITCODE -ne 0) { throw 'NSIS repackaging failed' }
    } finally { Pop-Location }
    if (-not (Test-Path -LiteralPath $repacked -PathType Leaf)) { throw 'NSIS repack output missing' }
    node $payloadInspector record-installer $payloadTrace repackedNsis $repacked
    if ($LASTEXITCODE -ne 0) { throw 'Repacked NSIS payload trace failed' }
  } finally {
    node $payloadInspector restore-nsis-app $payloadTrace $scripts[0].FullName
    if ($LASTEXITCODE -ne 0) { throw 'Tauri NSIS bundle-type restoration failed' }
  }
  $installer = @(Get-ChildItem -LiteralPath (Join-Path $app 'src-tauri/target/release/bundle/nsis') -Filter '*-setup.exe' -File)
  if ($installer.Count -ne 1) { throw 'Final NSIS destination is ambiguous' }
  if ((Get-FileHash -LiteralPath $installer[0].FullName -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $repacked -Algorithm SHA256).Hash) {
    throw 'Repacked NSIS is byte-identical to original; path-scoped patch was not reflected in output'
  }
  Move-Item -LiteralPath $repacked -Destination $installer[0].FullName -Force
  node $payloadInspector record-installer $payloadTrace finalInstaller $installer[0].FullName
  if ($LASTEXITCODE -ne 0) { throw 'Final NSIS payload trace failed' }
}
Stage 'candidate identity and metadata' {
  $env:UPSTREAM_COMMIT = $UpstreamCommit
  node (Join-Path $Maintenance 'scripts/collect-candidate.mjs') $source $candidate $MaintenanceCommit $payloadTrace
  if ($LASTEXITCODE -ne 0) { throw 'Candidate metadata gate failed' }
}
Write-Output "Cline Chinese unsigned candidate ready: $candidate"
