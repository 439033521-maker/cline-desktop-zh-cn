param(
  [Parameter(Mandatory=$true)][string]$Maintenance,
  [Parameter(Mandatory=$true)][string]$Work,
  [Parameter(Mandatory=$true)][string]$UpstreamCommit,
  [Parameter(Mandatory=$true)][string]$MaintenanceCommit
)
$ErrorActionPreference = 'Stop'
$source = Join-Path $Work 'resolved'
$app = Join-Path $source 'apps/examples/desktop-app'
$report = Join-Path $Work 'report'
$candidate = Join-Path $Work 'candidate'
New-Item -ItemType Directory -Force -Path $report,$candidate | Out-Null
$stages = @()
function Stage([string]$name, [scriptblock]$body) {
  $watch = [Diagnostics.Stopwatch]::StartNew()
  try {
    & $body
    $script:stages += [pscustomobject]@{stage=$name; seconds=[math]::Round($watch.Elapsed.TotalSeconds,1); pass=$true}
  } catch {
    $script:stages += [pscustomobject]@{stage=$name; seconds=[math]::Round($watch.Elapsed.TotalSeconds,1); pass=$false}
    $stages | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $report 'build-timings.json') -Encoding utf8
    throw
  }
  $stages | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $report 'build-timings.json') -Encoding utf8
}
if ($env:TAURI_SIGNING_PRIVATE_KEY -or $env:TAURI_SIGNING_PRIVATE_KEY_PATH) { throw 'Production updater signing key must not exist in cloud build environment' }
Stage 'dependency install' {
  Push-Location $source
  try {
    bun install
    if ($LASTEXITCODE -ne 0) {
      bun install --no-cache
      if ($LASTEXITCODE -ne 0) { throw 'Bun clean-install fallback failed' }
    }
  } finally { Pop-Location }
}
Stage 'SDK/Hub shared build' {
  Push-Location $source
  try { bun run build:sdk; if ($LASTEXITCODE -ne 0) { throw 'SDK build failed' } }
  finally { Pop-Location }
}
Stage 'typecheck' {
  Push-Location $app
  try { bun run typecheck; if ($LASTEXITCODE -ne 0) { throw 'Desktop typecheck failed' } }
  finally { Pop-Location }
}
Stage 'localization and Agent tests' {
  Push-Location $app
  try {
    bunx vitest run webview/i18n/agent-chat.test.ts webview/lib/run-error.zh.test.ts webview/hooks/use-app-update.test.tsx --config vitest.config.ts
    if ($LASTEXITCODE -ne 0) { throw 'Desktop Chinese tests failed' }
  } finally { Pop-Location }
  Push-Location $source
  try {
    bunx vitest run sdk/packages/shared/src/prompt/cline.test.ts sdk/packages/core/src/runtime/orchestration/session-runtime-orchestrator.test.ts
    if ($LASTEXITCODE -ne 0) { throw 'Agent prompt tests failed' }
  } finally { Pop-Location }
}
Stage 'install identity test' {
  Push-Location $app
  try {
    bun run test:windows-installer
    if ($LASTEXITCODE -ne 0) { throw 'NSIS path-scoped process test failed' }
  } finally { Pop-Location }
}
Stage 'Rust/Tauri and WebView/sidecar build' {
  Push-Location $app
  try {
    bunx tauri build --bundles nsis --config src-tauri/tauri.chinese-candidate.conf.json
    if ($LASTEXITCODE -ne 0) { throw 'Tauri build failed' }
  } finally { Pop-Location }
}
Stage 'path-scoped NSIS repackaging' {
  $scripts = @(Get-ChildItem -LiteralPath (Join-Path $app 'src-tauri/target/release/nsis') -Recurse -Filter installer.nsi -File)
  if ($scripts.Count -ne 1) { throw "Expected one generated installer.nsi, found $($scripts.Count)" }
  node (Join-Path $Maintenance 'pipeline/phase2/patch-nsis.mjs') $scripts[0].FullName 'Cline Chinese'
  if ($LASTEXITCODE -ne 0) { throw 'NSIS process scope patch failed' }
  & $env:MAKENSIS_PATH '/V3' $scripts[0].FullName
  if ($LASTEXITCODE -ne 0) { throw 'NSIS repackaging failed' }
}
Stage 'candidate identity and metadata' {
  $env:UPSTREAM_COMMIT = $UpstreamCommit
  node (Join-Path $Maintenance 'scripts/collect-candidate.mjs') $source $candidate $MaintenanceCommit
  if ($LASTEXITCODE -ne 0) { throw 'Candidate metadata gate failed' }
}
Write-Output "Cline Chinese unsigned candidate ready: $candidate"
