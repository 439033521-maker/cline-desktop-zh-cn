@echo off
setlocal
cd /d "%~dp0"
set "PATH=%~dp0tools\minisign;%~dp0..\SharedTools\Bun\1.3.13;%PATH%"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\sign-and-publish.ps1" %*
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo 发布未完成。请保留此窗口并检查上方原因。
pause
exit /b %RESULT%
