# Local minisign verifier

- Version: 0.12, official Windows x64 precompiled binary.
- Source: https://github.com/jedisct1/minisign/releases/download/0.12/minisign-0.12-win64.zip
- Archive SHA-256: `37B600344E20C19314B2E82813DB2BFDCC408B77B876F7727889DBD46D539479`.
- Extracted `minisign-win64/x86_64/minisign.exe` SHA-256: `5535BE9E4E123831EBE6EF324AAFE9DDE507015C176191F9E20C3AD60567F9E1`.
- The archive's `.minisig` verified against the upstream public key documented at https://github.com/jedisct1/minisign.
- `SIGN-AND-PUBLISH.cmd` adds this directory to the process PATH. It does not alter the machine or user PATH.

Do not build minisign locally on the release machine. Keep this vetted binary in the local maintenance package. If replacing it, update the version, source, hash, and publisher self-check together.
